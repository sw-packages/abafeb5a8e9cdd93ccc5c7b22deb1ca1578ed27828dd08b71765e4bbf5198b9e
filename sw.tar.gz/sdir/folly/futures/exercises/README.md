Working through [Programming Koans][1] can be a fun, lightweight, and fast way to
learn a new language or pattern with small, focused exercises. Therefore, we
present Koans for Futures.  Perhaps you will call them "Koans to Be".

Edit the topical files one at a time, moving the "compilation cursor" down one
exercise at a time, and getting them to pass by filling in the blanks.

[1] http://www.lauradhamilton.com/learn-a-new-programming-language-today-with-koans
[2] http://catb.org/esr/writings/unix-koans/ten-thousand.html
